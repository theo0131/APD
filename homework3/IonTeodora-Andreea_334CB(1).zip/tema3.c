#include "mpi.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Print whole topology
void print_topo(int rank, int no0, int no1, int no2, int *topo0, int *topo1,
                int *topo2) {
  printf("%d -> 0:", rank);
  for (int i = 0; i < no0 - 1; i++)
    printf("%d,", topo0[i]);
  printf("%d", topo0[no0 - 1]);

  printf(" 1:");
  for (int i = 0; i < no1 - 1; i++)
    printf("%d,", topo1[i]);
  printf("%d", topo1[no1 - 1]);

  printf(" 2:");
  for (int i = 0; i < no2 - 1; i++)
    printf("%d,", topo2[i]);
  printf("%d", topo2[no2 - 1]);
  printf("\n");
}

// Function to receive the modified array parts,
// to build the final array and to print it
void build_and_print_final(int N, int no_workers0, int no1, int no2,
                           int *workers0) {

  MPI_Status status;

  int final[N];
  int index = 0;
  for (int i = 0; i < no_workers0; i++) {
    int no_op;
    MPI_Recv(&no_op, 1, MPI_INT, workers0[i], 1, MPI_COMM_WORLD, &status);
    int work[no_op];
    MPI_Recv(&work, no_op, MPI_INT, workers0[i], 1, MPI_COMM_WORLD, &status);
    for (int j = 0; j < no_op; j++) {
      final[index] = work[j];
      index++;
    }
  }

  for (int i = 0; i < no1; i++) {
    int no_op;
    MPI_Recv(&no_op, 1, MPI_INT, 1, 1, MPI_COMM_WORLD, &status);
    int work[no_op];
    MPI_Recv(&work, no_op, MPI_INT, 1, 1, MPI_COMM_WORLD, &status);
    for (int j = 0; j < no_op; j++) {
      final[index] = work[j];
      index++;
    }
  }

  for (int i = 0; i < no2; i++) {
    int no_op;
    MPI_Recv(&no_op, 1, MPI_INT, 2, 1, MPI_COMM_WORLD, &status);
    int work[no_op];
    MPI_Recv(&work, no_op, MPI_INT, 2, 1, MPI_COMM_WORLD, &status);
    for (int j = 0; j < no_op; j++) {
      final[index] = work[j];
      index++;
    }
  }

  printf("Rezultat: ");
  for (int i = 0; i < N; i++) {
    printf("%d ", final[i]);
  }
  printf("\n");
}

// Function to send the whole topology to workers
void send_topo(int rank, int no0, int no1, int no2, int *topo0, int *topo1,
               int *topo2, int n, int *topo) {
  for (int i = 0; i < n; i++) {
    MPI_Send(&no0, 1, MPI_INT, topo[i], 1, MPI_COMM_WORLD);
    printf("M(%d,%d)\n", rank, topo[i]);
    MPI_Send(topo0, no0, MPI_INT, topo[i], 1, MPI_COMM_WORLD);
    printf("M(%d,%d)\n", rank, topo[i]);
    MPI_Send(&no1, 1, MPI_INT, topo[i], 1, MPI_COMM_WORLD);
    printf("M(%d,%d)\n", rank, topo[i]);
    MPI_Send(topo1, no1, MPI_INT, topo[i], 1, MPI_COMM_WORLD);
    printf("M(%d,%d)\n", rank, topo[i]);
    MPI_Send(&no2, 1, MPI_INT, topo[i], 1, MPI_COMM_WORLD);
    printf("M(%d,%d)\n", rank, topo[i]);
    MPI_Send(topo2, no2, MPI_INT, topo[i], 1, MPI_COMM_WORLD);
    printf("M(%d,%d)\n", rank, topo[i]);
  }
}

// Function to send the given topolgy to the dst1 and dst2 processes
void send_topo_to_others(int rank, int no, int *topo, int dst1, int dst2) {
  MPI_Send(&no, 1, MPI_INT, dst1, 1, MPI_COMM_WORLD);
  printf("M(%d,%d)\n", rank, dst1);
  MPI_Send(topo, no, MPI_INT, dst1, 1, MPI_COMM_WORLD);
  printf("M(%d,%d)\n", rank, dst1);

  MPI_Send(&no, 1, MPI_INT, dst2, 1, MPI_COMM_WORLD);
  printf("M(%d,%d)\n", rank, dst2);
  MPI_Send(topo, no, MPI_INT, dst2, 1, MPI_COMM_WORLD);
  printf("M(%d,%d)\n", rank, dst2);
}

// Function to send to workers their part of array
void send_part_array(int rank, int no_op, int no_workers, int *workers,
                     int *part) {

  // Send to workers their part of array
  int per_worker = no_op / no_workers;

  // Initialize the main number of operations for each worker
  int ops[no_workers];
  for (int i = 0; i < no_workers; i++) {
    ops[i] = per_worker;
  }
  int tmp = no_op - per_worker * no_workers;

  // Increase equally the number of tasks giving the remaining operations
  for (int i = 0; i < no_workers; i++) {
    if (tmp == 0) {
      break;
    } else if (tmp > 0) {
      ops[i]++;
      tmp--;
    }
  }

  // Create the array to be sent to each worker
  // according to their number of tasks
  int index = 0;
  for (int i = 0; i < no_workers; i++) {
    int work[ops[i]];
    for (int j = 0; j < ops[i]; j++) {
      work[j] = part[index];
      index++;
    }
    MPI_Send(&ops[i], 1, MPI_INT, workers[i], 1, MPI_COMM_WORLD);
    printf("M(%d,%d)\n", rank, workers[i]);
    MPI_Send(&work, ops[i], MPI_INT, workers[i], 1, MPI_COMM_WORLD);
    printf("M(%d,%d)\n", rank, workers[i]);
  }
}

// Function to build the array parts for process 1 and 2 and to send them
void send_parts_to_masters(int rank, int N, int no_op, int no_op0, int no_op1,
                           int no_op2) {

  // Build and send part for process 1
  int part1[no_op1];
  for (int i = 0; i < no_op1; i++) {
    part1[i] = i + no_op0;
  }

  MPI_Send(&no_op1, 1, MPI_INT, 1, 1, MPI_COMM_WORLD);
  printf("M(%d,%d)\n", rank, 1);
  MPI_Send(&part1, no_op1, MPI_INT, 1, 1, MPI_COMM_WORLD);
  printf("M(%d,%d)\n", rank, 1);

  // Build and send part for process 2
  int part2[no_op2];
  for (int i = 0; i < no_op2; i++) {
    part2[i] = i + no_op0 + no_op1;
  }

  MPI_Send(&no_op2, 1, MPI_INT, 2, 1, MPI_COMM_WORLD);
  printf("M(%d,%d)\n", rank, 2);
  MPI_Send(&part2, no_op2, MPI_INT, 2, 1, MPI_COMM_WORLD);
  printf("M(%d,%d)\n", rank, 2);
}

void rank0_attributions(int rank, char *argv[]) {
  FILE *fp0;
  fp0 = fopen("cluster0.txt", "r");
  int no_workers0;
  int *workers0;

  fscanf(fp0, "%d", &no_workers0);

  workers0 = (int *)malloc(no_workers0 * sizeof(int));
  for (int i = 0; i < no_workers0; i++) {
    fscanf(fp0, "%d", &workers0[i]);
    MPI_Send(&rank, 1, MPI_INT, workers0[i], 1, MPI_COMM_WORLD);
    printf("M(%d,%d)\n", rank, workers0[i]);
  }
  int master = -1;

  // Send the process 0 topology to processes 1 and 2
  send_topo_to_others(rank, no_workers0, workers0, 1, 2);

  int no1, no2;
  MPI_Status status;

  // Receive from processes 1 and 2 their topology
  MPI_Recv(&no1, 1, MPI_INT, 1, 1, MPI_COMM_WORLD, &status);
  int topo1[no1];
  MPI_Recv(&topo1, no1, MPI_INT, 1, 1, MPI_COMM_WORLD, &status);

  MPI_Recv(&no2, 1, MPI_INT, 2, 1, MPI_COMM_WORLD, &status);
  int topo2[no2];
  MPI_Recv(&topo2, no2, MPI_INT, 2, 1, MPI_COMM_WORLD, &status);

  // Print whole topology
  print_topo(rank, no_workers0, no1, no2, workers0, topo1, topo2);

  // Send wholoe topology to workers
  send_topo(rank, no_workers0, no1, no2, workers0, topo1, topo2, no_workers0,
            workers0);

  fclose(fp0);

  int N = atoi(argv[1]);
  int V[N];
  for (int i = 0; i < N; i++) {
    V[i] = i;
  }

  // Total number of workers
  int no_op = no_workers0 + no1 + no2;

  // Number of operations for process 0 to distribute
  int no_op0 = N / no_op * no_workers0;

  // Number of operations for process 1 to distribute
  int no_op1 = N / no_op * no1;

  // Number of operations for process 2 to distribute
  int no_op2 = N / no_op * no2;

  int aux = N - no_op0 - no_op1 - no_op2;

  int tmp0 = no_op0;
  int tmp1 = no_op1;
  int tmp2 = no_op2;
  while (aux > 0) {
    if (tmp0 > 0) {
        no_op0++;
        tmp0--;
        aux--;
    }
    else if (tmp0 == 0 && tmp1 > 0) {
        no_op1++;
        tmp1--;
        aux--;
    }
    else if (tmp0 == 0 && tmp1 == 0 && tmp2 > 0) {
        no_op2++;
        tmp2--;
        aux--;
    }
  }

  // Construct part for process 0
  int part0[no_op0];
  for (int i = 0; i < no_op0; i++) {
    part0[i] = i;
  }

  send_parts_to_masters(rank, N, no_op, no_op0, no_op1, no_op2);

  // Send to workers their part of array
  send_part_array(rank, no_op0, no_workers0, workers0, part0);

  // Build and print the final array by receiving the parts of the array
  // from workers of process 0 and from masters 1 and 2
  build_and_print_final(N, no_workers0, no1, no2, workers0);
}

void rank1_attributions(int rank) {
  FILE *fp1;
  fp1 = fopen("cluster1.txt", "r");
  int no_workers1;
  int *workers1;

  // Read local workers
  fscanf(fp1, "%d", &no_workers1);
  workers1 = (int *)malloc(no_workers1 * sizeof(int));
  for (int i = 0; i < no_workers1; i++) {
    fscanf(fp1, "%d", &workers1[i]);
    MPI_Send(&rank, 1, MPI_INT, workers1[i], 1, MPI_COMM_WORLD);
    printf("M(%d,%d)\n", rank, workers1[i]);
  }
  int master = -1;

  // Send topology to processes 0 and 2
  send_topo_to_others(rank, no_workers1, workers1, 0, 2);

  int no0, no2;
  MPI_Status status;

  // Receive topology from processes 0 and 2
  MPI_Recv(&no0, 1, MPI_INT, 0, 1, MPI_COMM_WORLD, &status);
  int topo0[no0];
  MPI_Recv(&topo0, no0, MPI_INT, 0, 1, MPI_COMM_WORLD, &status);

  MPI_Recv(&no2, 1, MPI_INT, 2, 1, MPI_COMM_WORLD, &status);
  int topo2[no2];
  MPI_Recv(&topo2, no2, MPI_INT, 2, 1, MPI_COMM_WORLD, &status);

  // Print final topology
  print_topo(rank, no0, no_workers1, no2, topo0, workers1, topo2);

  // Send final topology to workers
  send_topo(rank, no0, no_workers1, no2, topo0, workers1, topo2, no_workers1,
            workers1);

  fclose(fp1);

  // Receive from process 0 the part of the array to be distributed
  int no_op;
  MPI_Recv(&no_op, 1, MPI_INT, 0, 1, MPI_COMM_WORLD, &status);
  int part[no_op];
  MPI_Recv(&part, no_op, MPI_INT, 0, 1, MPI_COMM_WORLD, &status);

  // Send to workers their part of array
  send_part_array(rank, no_op, no_workers1, workers1, part);

  // For each worker
  for (int i = 0; i < no_workers1; i++) {

    // Receive the modified part of the array
    int no_op;
    MPI_Recv(&no_op, 1, MPI_INT, workers1[i], 1, MPI_COMM_WORLD, &status);
    int work[no_op];
    MPI_Recv(&work, no_op, MPI_INT, workers1[i], 1, MPI_COMM_WORLD, &status);

    // Send the modified part of the array to process 0
    MPI_Send(&no_op, 1, MPI_INT, 0, 1, MPI_COMM_WORLD);
    printf("M(%d,%d)\n", rank, 0);
    MPI_Send(&work, no_op, MPI_INT, 0, 1, MPI_COMM_WORLD);
    printf("M(%d,%d)\n", rank, 0);
  }
}

void rank2_attributions(int rank) {
  FILE *fp2;
  fp2 = fopen("cluster2.txt", "r");
  int no_workers2;
  int *workers2;

  // Read local workers
  fscanf(fp2, "%d", &no_workers2);
  workers2 = (int *)malloc(no_workers2 * sizeof(int));
  for (int i = 0; i < no_workers2; i++) {
    fscanf(fp2, "%d", &workers2[i]);
    MPI_Send(&rank, 1, MPI_INT, workers2[i], 1, MPI_COMM_WORLD);
    printf("M(%d,%d)\n", rank, workers2[i]);
  }
  int master = -1;

  // Send topology to processes 0 and 1
  send_topo_to_others(rank, no_workers2, workers2, 0, 1);

  int no1, no0;
  MPI_Status status;

  // Receive topology from processes 0 and 1
  MPI_Recv(&no0, 1, MPI_INT, 0, 1, MPI_COMM_WORLD, &status);
  int topo0[no0];
  MPI_Recv(&topo0, no0, MPI_INT, 0, 1, MPI_COMM_WORLD, &status);

  MPI_Recv(&no1, 1, MPI_INT, 1, 1, MPI_COMM_WORLD, &status);
  int topo1[no1];
  MPI_Recv(&topo1, no1, MPI_INT, 1, 1, MPI_COMM_WORLD, &status);

  // Print final topology
  print_topo(rank, no0, no1, no_workers2, topo0, topo1, workers2);

  // Send final topology to workers
  send_topo(rank, no0, no1, no_workers2, topo0, topo1, workers2, no_workers2,
            workers2);

  fclose(fp2);

  // Receive from process 0 the part of the array to be distributed
  int no_op;
  MPI_Recv(&no_op, 1, MPI_INT, 0, 1, MPI_COMM_WORLD, &status);
  int part[no_op];
  MPI_Recv(&part, no_op, MPI_INT, 0, 1, MPI_COMM_WORLD, &status);

  // Send to workers their part of array
  send_part_array(rank, no_op, no_workers2, workers2, part);

  // For each worker
  for (int i = 0; i < no_workers2; i++) {

    // Receive the modified part of the array
    int no_op;
    MPI_Recv(&no_op, 1, MPI_INT, workers2[i], 1, MPI_COMM_WORLD, &status);
    int work[no_op];
    MPI_Recv(&work, no_op, MPI_INT, workers2[i], 1, MPI_COMM_WORLD, &status);

    // Send the modified part of the array to process 0
    MPI_Send(&no_op, 1, MPI_INT, 0, 1, MPI_COMM_WORLD);
    printf("M(%d,%d)\n", rank, 0);
    MPI_Send(&work, no_op, MPI_INT, 0, 1, MPI_COMM_WORLD);
    printf("M(%d,%d)\n", rank, 0);
  }
}

void worker_attributions(int rank) {
  MPI_Status status;
  int no0, no1, no2;
  int master = -1;

  // Receive the master rank
  if (master == -1) {
    MPI_Recv(&master, 1, MPI_INT, MPI_ANY_SOURCE, 1, MPI_COMM_WORLD, &status);
  }

  // Receive the topologies of processes 0, 1 and 2
  MPI_Recv(&no0, 1, MPI_INT, master, 1, MPI_COMM_WORLD, &status);
  int topo0[no0];
  MPI_Recv(&topo0, no0, MPI_INT, master, 1, MPI_COMM_WORLD, &status);

  MPI_Recv(&no1, 1, MPI_INT, master, 1, MPI_COMM_WORLD, &status);
  int topo1[no1];
  MPI_Recv(&topo1, no1, MPI_INT, master, 1, MPI_COMM_WORLD, &status);

  MPI_Recv(&no2, 1, MPI_INT, master, 1, MPI_COMM_WORLD, &status);
  int topo2[no2];
  MPI_Recv(&topo2, no2, MPI_INT, master, 1, MPI_COMM_WORLD, &status);

  // Print the final topology
  print_topo(rank, no0, no1, no2, topo0, topo1, topo2);

  // Receive the array part to be modified
  int no_op;
  MPI_Recv(&no_op, 1, MPI_INT, master, 1, MPI_COMM_WORLD, &status);
  int work[no_op];
  MPI_Recv(&work, no_op, MPI_INT, master, 1, MPI_COMM_WORLD, &status);

  // Modify the array elements
  for (int i = 0; i < no_op; i++) {
    work[i] *= 2;
  }

  // Send the modified array part to the master process
  MPI_Send(&no_op, 1, MPI_INT, master, 1, MPI_COMM_WORLD);
  printf("M(%d,%d)\n", rank, master);
  MPI_Send(&work, no_op, MPI_INT, master, 1, MPI_COMM_WORLD);
  printf("M(%d,%d)\n", rank, master);
}

int main(int argc, char *argv[]) {
  int numtasks, rank, len;
  char hostname[MPI_MAX_PROCESSOR_NAME];

  // Initialize
  MPI_Init(&argc, &argv);
  MPI_Comm_size(MPI_COMM_WORLD, &numtasks);
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Get_processor_name(hostname, &len);

  if (rank == 0) {

    // Execute process 0 attributions
    rank0_attributions(rank, argv);

  } else if (rank == 1) {

    // Execute process 1 attributions
    rank1_attributions(rank);

  } else if (rank == 2) {

    // Execute process 2 attributions
    rank2_attributions(rank);

  } else {

    // Execute worker attributions
    worker_attributions(rank);
  }

  MPI_Finalize();
  return 0;
}
