import java.util.*;
import java.util.concurrent.*;

class Reduce implements Runnable {
    String path;

    // List of dictionaries for file
    ConcurrentLinkedQueue<ConcurrentHashMap<Integer, Integer>> list;

    // Final dictionary for file
    ConcurrentHashMap<String, ConcurrentHashMap<Integer, Integer>> dict;

    // List of lists with max len words per fragments for the current file
    ConcurrentLinkedQueue<ConcurrentLinkedQueue<String>> max_words_list;

    // Final list of maximum length words
    ConcurrentHashMap<String, ConcurrentLinkedQueue<String>> max_words;

    // Hashmap of rank for all files
    ConcurrentHashMap<String, Float> ranks;

    // Hashmap of maximum length and number of words for all files
    ConcurrentHashMap<String, ArrayList<Integer>> values;

    public Reduce(String path,
                  ConcurrentLinkedQueue<ConcurrentHashMap<Integer, Integer>> l,
                  ConcurrentLinkedQueue<ConcurrentLinkedQueue<String>> words_list,
                  ConcurrentHashMap<String, Float> rang_list,
                  ConcurrentHashMap<String, ArrayList<Integer>> values_list) {
        this.path = path;
        this.list = l;
        this.max_words_list = words_list;
        this.dict = new ConcurrentHashMap<>();
        this.max_words = new ConcurrentHashMap<>();
        this.ranks = rang_list;
        this.values = values_list;
    }

    // Recursive function to calculate the n fibonacci number
    int fib(int n)
    {
        if (n <= 1)
            return n;
        int val1, val2;
        val1 = fib(n-1);
        val2 = fib(n-2);

        return val1 + val2;
    }

    @Override
    public void run() {

        // Initialize the total number of words in file
        int total_no_words = 0;
        Set<Integer> len_list = new HashSet<>();
        dict.putIfAbsent(path, new ConcurrentHashMap<>());

        // For each dictionary in list
        for (ConcurrentHashMap<Integer, Integer> l : list) {

            // Calculate the number of words of each length
            for (Integer i : l.keySet()) {
                if (len_list.contains(i)) {
                    final int tmp_no = dict.get(path).get(i) + l.get(i);
                    dict.get(path).replace(i, tmp_no);
                }
                else
                    len_list.add(i);

                dict.get(path).putIfAbsent(i, l.get(i));

                if (i != 0)
                    total_no_words += l.get(i);
            }
        }

        // Calculate the rank of the file
        int sum = 0;
        for (Integer i : dict.get(path).keySet()) {

            int fib_val = fib(i+1);
            if (i != 0)
                sum += fib_val * dict.get(path).get(i);
        }

        float rang = (float)sum/total_no_words;
        ranks.putIfAbsent(path, rang);

        // Create the list of maximum length words
        max_words.putIfAbsent(path, new ConcurrentLinkedQueue<>());
        int max_len = 0;
        for (ConcurrentLinkedQueue<String> listSet : max_words_list) {
            int tmp_len = 0;
            if (listSet.peek() != null) {
                tmp_len = listSet.peek().length();
            }

            // If a new max length is found, update max_len and list
            if (tmp_len > max_len) {
                max_len = tmp_len;
                max_words.compute(path, (key, oldList) -> listSet);
            }
            // If the word has the maximum len, add it to the list
            else if (tmp_len == max_len) {
                for (String str : listSet) {
                    max_words.get(path).add(str);
                }
            }
        }

        int word_max_len = Objects.requireNonNull(max_words.get(path).peek()).length();
        int no_max = max_words.get(path).size();
        ArrayList<Integer> aux_array = new ArrayList<>();

        // Add the max len and the number of words
        aux_array.add(0, word_max_len);
        aux_array.add(1, no_max);
        values.putIfAbsent(path, aux_array);
    }
}