import java.io.*;
import java.util.*;
import java.util.concurrent.*;

public class MyMap implements Runnable {
    String path;
    int offset;
    int frag_size;

    ConcurrentHashMap<Integer, Integer> m;
    ConcurrentLinkedQueue<String> list;

    // The list of dictionaries for each fragment in files
    ConcurrentHashMap<String, ConcurrentLinkedQueue<ConcurrentHashMap<Integer, Integer>>> dict_list;

    // The list of maximum length words for each fragment in files
    ConcurrentHashMap<String, ConcurrentLinkedQueue<ConcurrentLinkedQueue<String>>> max_words_list;

    public MyMap(String path, int offset, int frag_size,
                 ConcurrentHashMap<String, ConcurrentLinkedQueue<ConcurrentHashMap<Integer, Integer>>> dicts,
                 ConcurrentHashMap<String, ConcurrentLinkedQueue<ConcurrentLinkedQueue<String>>> words_list) {
        this.path = path;
        this.offset = offset;
        this.frag_size = frag_size;
        m = new ConcurrentHashMap<>();
        list = new ConcurrentLinkedQueue<>();
        dict_list = dicts;
        max_words_list = words_list;
    }

    @Override
    public void run() {
        String file_path = "../" + path;
        String delimiters = "[;:/?~.,><`\\[\\]{}()!@#$%^&\\-_+'=*\"| \t\r\n\0]";

        int before = 0;
        try {
            File file = new File(file_path);
            RandomAccessFile raf = new RandomAccessFile(file_path, "r");
            byte[] aux = new byte[1];
            int dimens;

            // Beginning of fragment
            if (offset > 0) {

                // Set the cursor at the offset - 1
                raf.seek(offset - 1);

                // Read the character before the fragment
                raf.read(aux, 0, 1);

                // As long as the character is not a delimiter
                while (!delimiters.contains(new String(aux))) {
                    if (offset + before >= file.length()) {
                        break;
                    }

                    // Go further to the next char
                    raf.seek(offset + before);
                    aux = new byte[1];

                    // read it
                    raf.read(aux, 0, 1);

                    // and increase the value to be added to the offset
                    before += 1;
                }
            }

            // Set the number of characters to be read
            if (file.length() - offset < frag_size) {
                dimens = (int) (file.length() - offset);
            }
            else {
                dimens = frag_size;
            }

            // End of fragment

            // Set the cursor at the last character
            raf.seek(offset + dimens - 1);
            aux = new byte[1];

            // Read it
            raf.read(aux, 0, 1);
            String character = new String(aux);
            int end = 0;

            // As long as the character is not a delimiter
            while (!delimiters.contains(character)) {
                if (offset + dimens + end >= file.length())
                    break;

                // go to the next character
                raf.seek(offset + dimens + end);
                aux = new byte[1];

                // read it
                raf.read(aux, 0, 1);
                character = new String(aux);

                // and increase the padding
                end += 1;
            }

            // Final fragment
            raf.seek(offset + before);
            byte[] data = new byte[dimens - before + end];
            raf.read(data, 0, dimens - before + end);
            String fragment = new String(data);
            int max_len = 0;
            String[] words = fragment.split(delimiters);

            // Split the final string in words
            Set<Integer> len_list = new HashSet<>();

            // Go through all words
            for (String word : words) {
                int len = word.length();
                if (len_list.contains(len)) {
                    final int tmp_no = m.get(len) + 1;

                    // update the number of words with length len
                    m.replace(len, tmp_no);
                }
                else
                    len_list.add(len);

                // Add the length if it is the first occurrence
                m.putIfAbsent(len, 1);

                // Calculate the maximum length and keep the words of max len
                if (max_len < len) {
                    list.clear();
                    list.add(word);
                    max_len = len;
                }
                else if (max_len == len) {
                    list.add(word);
                }
            }

            // Add to the dictionaries the hashmap for the fragment with the name of the file as key
            dict_list.putIfAbsent(path, new ConcurrentLinkedQueue<>());
            ConcurrentLinkedQueue<ConcurrentHashMap<Integer, Integer>> tmp_list = dict_list.get(path);
            tmp_list.add(m);

            // Add the fragment maximum length words to the list with the name of the file as key
            max_words_list.putIfAbsent(path, new ConcurrentLinkedQueue<>());
            ConcurrentLinkedQueue<ConcurrentLinkedQueue<String>> tmp_list2 = max_words_list.get(path);
            tmp_list2.add(list);

        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
}
