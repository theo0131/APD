import java.io.*;
import java.util.*;
import java.io.File;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.Scanner;

public class Tema2 {

    // Fragment size
    static int frag_size;

    // Number of files
    static int no_files;

    // The list of dictionaries for each file
    static ConcurrentHashMap<String, ConcurrentLinkedQueue<ConcurrentHashMap<Integer, Integer>>> dict_list;

    // The list of maximum length words for each file
    static ConcurrentHashMap<String, ConcurrentLinkedQueue<ConcurrentLinkedQueue<String>>> max_words_list;

    // List of ranks for all files
    static ConcurrentHashMap<String, Float> ranks;

    // The maximum length and the number of words with maximum length
    static ConcurrentHashMap<String, ArrayList<Integer>> values;

    public static HashMap<String, Float> sortByValue(ConcurrentHashMap<String, Float> map)
    {
        // Create a list from elements of hashmap
        List<Map.Entry<String, Float> > list =
                new LinkedList<>(map.entrySet());

        // Sort the list
        list.sort((o1, o2) -> (o2.getValue()).compareTo(o1.getValue()));

        // Put data from sorted list to hashmap
        HashMap<String, Float> temp = new LinkedHashMap<>();
        for (Map.Entry<String, Float> aa : list) {
            temp.put(aa.getKey(), aa.getValue());
        }
        return temp;
    }

    public static void main(String[] args) {
        if (args.length < 3) {
            System.err.println("Usage: Tema2 <workers> <in_file> <out_file>");
            return;
        }

        // Initialize the variables
        ArrayList<String> files = new ArrayList<>();
        dict_list = new ConcurrentHashMap<>();
        max_words_list = new ConcurrentHashMap<>();
        ranks = new ConcurrentHashMap<>();
        values = new ConcurrentHashMap<>();

        // Get the number of workers(threads)
        int no_workers = Integer.parseInt(args[0]);

        AtomicInteger inQueue1 = new AtomicInteger(0);
        AtomicInteger inQueue2 = new AtomicInteger(0);

        // Create the executors service for Map operations and Reduce operations
        ExecutorService tpe = Executors.newFixedThreadPool(no_workers);
        ExecutorService tpe2 = Executors.newFixedThreadPool(no_workers);

        try {
            File file = new File(args[1]);
            Scanner myReader = new Scanner(file);

            // Read fragment size
            if (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                frag_size = Integer.parseInt(data);
            }

            // Read number of files
            if (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                no_files = Integer.parseInt(data);
            }
            while (myReader.hasNextLine()) {
                int offset = 0;

                // Read the name of the file
                String file_path = myReader.nextLine();
                String path = "../" + file_path;
                files.add(file_path);
                File tmp = new File(path);

                // Create a MyMap task for each fragment of the file
                while ((int) tmp.length() >= offset) {
                    inQueue1.incrementAndGet();
                    MyMap runni = new MyMap(file_path, offset, frag_size, dict_list, max_words_list);
                    tpe.submit(runni);

                    // Go to the next fragment
                    offset += frag_size;
                }
            }
            myReader.close();

            // Wait for workers to finish their tasks
            tpe.shutdown();
            try {
                tpe.awaitTermination(1200, TimeUnit.SECONDS);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            // For each file, create a Reduce task that receives
            // the list of fragments dictionaries and maximum length words
            for (String s : files) {
                inQueue2.incrementAndGet();
                Reduce runni = new Reduce(s, dict_list.get(s), max_words_list.get(s), ranks, values);
                tpe2.submit(runni);
            }

            // Wait for workers to finish their tasks
            tpe2.shutdown();
            try {
                tpe2.awaitTermination(1200, TimeUnit.SECONDS);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            // Get the sorted list of ranks
            Map<String, Float> sorted_ranks = sortByValue(ranks);
            try {
                FileWriter myWriter = new FileWriter(args[2]);

                // Print for each file the name, rank, the biggest length,
                // number of words of the biggest length
                for (String s : sorted_ranks.keySet()) {
                    File tmp = new File(s);
                    String to_print = tmp.getName() +","+ String.format("%.2f", ranks.get(s))
                            +","+ values.get(s).get(0) +","+ values.get(s).get(1) + "\n";
                    myWriter.write(to_print);
                    myWriter.flush();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }



        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
}
