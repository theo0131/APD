/* Ion Teodora-Andreea, 334CB */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "genetic_algorithm.h"
#include <pthread.h>
#include <unistd.h>
#include <sys/time.h>


int main(int argc, char *argv[]) {

	int no_threads = atoi(argv[3]);
	
	// set of threads
	pthread_t ids[no_threads];

	// array with all the objects that can be placed in the sack
	sack_object *objects = NULL;

	// number of objects
	int object_count = 0;

	// maximum weight that can be carried in the sack
	int sack_capacity = 0;

	// number of generations
	int generations_count = 0;

	if (!read_input(&objects, &object_count, &sack_capacity, &generations_count, argc, argv)) {
		return 0;
	}

	// Define attributes and parameters in a structure
	// and create the threads
	int chk_func;
	pthread_barrier_t barrier;
	pthread_barrier_init(&barrier, NULL, no_threads);
	individual *current_generation = (individual*) calloc(object_count, sizeof(individual));
	individual *next_generation = (individual*) calloc(object_count, sizeof(individual));

    for (int i = 0; i < no_threads; i++) {
        ids[i] = i;

        struct ThFun_Params *limits = calloc(sizeof(struct ThFun_Params), 1);

        limits->id = i;
        limits->no_threads = no_threads;
        limits->barrier = &barrier;

        limits->objects = objects;
    	limits->object_count = object_count;
    	limits->generations_count = generations_count;
    	limits->sack_capacity = sack_capacity;
    	limits->current_generation = current_generation;
    	limits->next_generation = next_generation;
    	limits->tmp = NULL;

        chk_func = pthread_create(&ids[i], NULL, run_genetic_algorithm, limits);
        if (chk_func) {
            printf("Error when creating the thread\n");
            exit(EXIT_FAILURE);
        }

    }

    // Join the threads
	void *returned;
    for (int i = 0; i < no_threads; i++) {
        chk_func = pthread_join(ids[i], &returned);
        
        if (chk_func) {
            exit(EXIT_FAILURE);
        }
    }


	free(objects);

	pthread_exit(NULL);

	return 0;
}