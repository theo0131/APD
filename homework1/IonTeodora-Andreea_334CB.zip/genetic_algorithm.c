/* Ion Teodora-Andreea, 334CB */

#include "genetic_algorithm.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int read_input(sack_object **objects, int *object_count, int *sack_capacity,
			   int *generations_count, int argc, char *argv[]) {
  FILE *fp;

  if (argc < 3) {
	fprintf(stderr, "Usage:\n\t./tema1 in_file generations_count\n");
	return 0;
  }

  fp = fopen(argv[1], "r");
  if (fp == NULL) {
	return 0;
  }

  if (fscanf(fp, "%d %d", object_count, sack_capacity) < 2) {
	fclose(fp);
	return 0;
  }

  if (*object_count % 10) {
	fclose(fp);
	return 0;
  }

  sack_object *tmp_objects =
	  (sack_object *)calloc(*object_count, sizeof(sack_object));

  for (int i = 0; i < *object_count; ++i) {
	if (fscanf(fp, "%d %d", &tmp_objects[i].profit, &tmp_objects[i].weight) <
		2) {
	  free(objects);
	  fclose(fp);
	  return 0;
	}
  }

  fclose(fp);

  *generations_count = (int)strtol(argv[2], NULL, 10);

  if (*generations_count == 0) {
	free(tmp_objects);

	return 0;
  }

  *objects = tmp_objects;

  return 1;
}

void print_objects(const sack_object *objects, int object_count) {
  for (int i = 0; i < object_count; ++i) {
	printf("%d %d\n", objects[i].weight, objects[i].profit);
  }
}

void print_generation(const individual *generation, int limit) {
  for (int i = 0; i < limit; ++i) {
	for (int j = 0; j < generation[i].chromosome_length; ++j) {
		printf("%d ", generation[i].chromosomes[j]);
	}

	printf("\n%d - %d\n", i, generation[i].fitness);
  }
}

void print_best_fitness(const individual *generation) {
  printf("%d\n", generation[0].fitness);
}

void compute_fitness_function(const sack_object *objects,
							  individual *generation, int object_count,
							  int sack_capacity, int start, int end) {
  int weight;
  int profit;

  for (int i = start; i < end; ++i) {
	weight = 0;
	profit = 0;

	for (int j = 0; j < generation[i].chromosome_length; ++j) {
	  if (generation[i].chromosomes[j]) {
		weight += objects[j].weight;
		profit += objects[j].profit;
	  }
	}

	generation[i].fitness = (weight <= sack_capacity) ? profit : 0;
  }
}

int cmpfunc(const void *a, const void *b) {
  int i;
  individual *first = (individual *)a;
  individual *second = (individual *)b;

  int res = second->fitness - first->fitness; // decreasing by fitness
  if (res == 0) {
	int first_count = 0, second_count = 0;

	for (i = 0; i < first->chromosome_length && i < second->chromosome_length;
		 ++i) {
	  first_count += first->chromosomes[i];
	  second_count += second->chromosomes[i];
	}

	res = first_count -
		  second_count; // increasing by number of objects in the sack
	if (res == 0) {
	  return second->index - first->index;
	}
  }

  return res;
}

void mutate_bit_string_1(const individual *ind, int generation_index) {
  int i, mutation_size;
  int step = 1 + generation_index % (ind->chromosome_length - 2);

  if (ind->index % 2 == 0) {
	// for even-indexed individuals, 
	// mutate the first 40% chromosomes by a given step
	mutation_size = ind->chromosome_length * 4 / 10;
	for (i = 0; i < mutation_size; i += step) {
	  ind->chromosomes[i] = 1 - ind->chromosomes[i];
	}
  } else {
	// for even-indexed individuals, 
	// mutate the last 80% chromosomes by a given step
	mutation_size = ind->chromosome_length * 8 / 10;
	for (i = ind->chromosome_length - mutation_size;
		 i < ind->chromosome_length; i += step) {
	  ind->chromosomes[i] = 1 - ind->chromosomes[i];
	}
  }
}

void mutate_bit_string_2(const individual *ind, int generation_index) {
  int step = 1 + generation_index % (ind->chromosome_length - 2);

  // mutate all chromosomes by a given step
  for (int i = 0; i < ind->chromosome_length; i += step) {
	ind->chromosomes[i] = 1 - ind->chromosomes[i];
  }
}

void crossover(individual *parent1, individual *child1, int generation_index) {
  individual *parent2 = parent1 + 1;
  individual *child2 = child1 + 1;
  int count = 1 + generation_index % parent1->chromosome_length;

  memcpy(child1->chromosomes, parent1->chromosomes, count * sizeof(int));
  memcpy(child1->chromosomes + count, parent2->chromosomes + count,
		 (parent1->chromosome_length - count) * sizeof(int));

  memcpy(child2->chromosomes, parent2->chromosomes, count * sizeof(int));
  memcpy(child2->chromosomes + count, parent1->chromosomes + count,
		 (parent1->chromosome_length - count) * sizeof(int));
}

void copy_individual(const individual *from, const individual *to) {
  memcpy(to->chromosomes, from->chromosomes,
		 from->chromosome_length * sizeof(int));
}

void free_generation(individual *generation) {
  int i;

  for (i = 0; i < generation->chromosome_length; ++i) {
	free(generation[i].chromosomes);
	generation[i].chromosomes = NULL;
	generation[i].fitness = 0;
  }
}

/* Function to merge 2 sections in the array v
		The sections are given by l(left limit), m(middle), r(right) */
void merge(individual *v, int l, int m, int r) {
  int left_end = m - l + 1;
  int right_end = r - m;

  /* Define and allocate temporary arrays */
  individual *tmp_left = (individual *)calloc(left_end, sizeof(individual));
  individual *tmp_right = (individual *)calloc(right_end, sizeof(individual));

  /* Create copy of the left section */
  for (int i = 0; i < left_end; i++)
	tmp_left[i] = v[l + i];

  /* Create copy of the right section */
  for (int j = 0; j < right_end; j++)
	tmp_right[j] = v[m + 1 + j];

  int i = 0, j = 0;

  // Index in the result array after merge
  int k = l;

  /* Merge the temporary arrays into a section of v from l to r*/
  while (i < left_end && j < right_end) {
	if (cmpfunc(&tmp_left[i], &tmp_right[j]) <= 0) {

	  // If the left element is smaller, add it first
	  v[k] = tmp_left[i];
	  i++;
	} else {

	  // If the right element is smaller, add it first
	  v[k] = tmp_right[j];
	  j++;
	}

	// Increase the index in the merged array
	k++;
  }

  /* Copy the rest of the elements from tmp_left[] */
  while (i < left_end) {
	v[k] = tmp_left[i];
	i++;
	k++;
  }

  /* Copy the rest of the elements from tmp_right[] */
  while (j < right_end) {
	v[k] = tmp_right[j];
	j++;
	k++;
  }
}

/* Function to calculate and return the minimum of the 2 given numbers */
int min(int a, int b) {
  if (a <= b) {
	return a;
  }
  return b;
}

/* Function to interate for each generation, sort and modify sections */
void iterate_generations(struct ThFun_Params *get_args) {

  int count, cursor;
  int start, end;

  // Calculate the limits where to apply the operations
  // Each portion is given to a thread
  start = get_args->id * (double)get_args->object_count / get_args->no_threads;
  end = min((get_args->id + 1) * (double)get_args->object_count /
				get_args->no_threads,
			get_args->object_count);

  individual *current_generation = get_args->current_generation;
  individual *next_generation = get_args->next_generation;

  // Iterate for each generation
  for (int k = 0; k < get_args->generations_count; ++k) {
	cursor = 0;

	// Compute fitness between the limits
	compute_fitness_function(get_args->objects, current_generation,
							 get_args->object_count, get_args->sack_capacity,
							 start, end);

	// Wait for all threads
	pthread_barrier_wait(get_args->barrier);

	// Sort the section
	qsort(current_generation + start, end - start,
		 sizeof(individual), cmpfunc);

	// Wait for all threads
	pthread_barrier_wait(get_args->barrier);

	// After each section is sorted,
	// merge all sections into one, on a single thread
	// Firts section is merged with the second
	// and the result with the next one
	if (get_args->id == 0) {

	  // The left limit stays the same
	  int l = 0 * (double)get_args->object_count / get_args->no_threads;

	  for (int i = 0; i < get_args->no_threads; i++) {

		// Calculate the right limit and the middle point
		int r =
			min((i + 2) * (double)get_args->object_count 
				/ get_args->no_threads,
				get_args->object_count - 1);
		int m = l + (r - l) / 2;
		merge(current_generation, l, m, r);
	  }
	}

	// Wait for all threads
	pthread_barrier_wait(get_args->barrier);

	// Keep first 30% children (elite children selection)
	count = get_args->object_count * 3 / 10;

	// Calculate the section limits of the first 30% for the current thread
	int left = get_args->id * (double)count / get_args->no_threads;
	int right =
		min((get_args->id + 1) * (double)count / get_args->no_threads, count);

	for (int i = left; i < right; ++i) {
	  copy_individual(current_generation + i, next_generation + i);
	}
	pthread_barrier_wait(get_args->barrier);
	cursor = count;

	// Mutate first 20% children with the first version of bit string mutation
	count = get_args->object_count * 2 / 10;

	// Calculate the section limits of the first 20% for the current thread
	left = get_args->id * (double)count / get_args->no_threads;
	right =
		min((get_args->id + 1) * (double)count / get_args->no_threads, count);

	for (int i = left; i < right; ++i) {
	  copy_individual(current_generation + i, next_generation + cursor + i);
	  mutate_bit_string_1(next_generation + cursor + i, k);
	}
	pthread_barrier_wait(get_args->barrier);
	cursor += count;

	// Mutate next 20% children with the second version of bit string mutation
	count = get_args->object_count * 2 / 10;
	left = get_args->id * (double)count / get_args->no_threads;
	right =
		min((get_args->id + 1) * (double)count / get_args->no_threads, count);

	for (int i = left; i < right; ++i) {
	  copy_individual(current_generation + i + count,
					  next_generation + cursor + i);
	  mutate_bit_string_2(next_generation + cursor + i, k);
	}
	pthread_barrier_wait(get_args->barrier);
	cursor += count;

	// Crossover first 30% parents with one-point crossover
	// (if there is an odd number of parents, the last one is kept as such)
	count = get_args->object_count * 3 / 10;

	if (count % 2 == 1) {
	  copy_individual(current_generation + get_args->object_count - 1,
					  next_generation + cursor + count - 1);
	  count--;
	}

	for (int i = 0; i < count; i += 2) {
	  crossover(current_generation + i, next_generation + cursor + i, k);
	}

	// Swap the arrays
	get_args->tmp = current_generation;
	current_generation = next_generation;
	next_generation = get_args->tmp;

	for (int i = 0; i < get_args->object_count; ++i) {
	  current_generation[i].index = i;
	}

	if (k % 5 == 0 && get_args->id == 0) {
	  print_best_fitness(current_generation);
	}
  }
}

/* Function to run the genetic algorithm */
void *run_genetic_algorithm(void *args) {
	
  // Extract the structure from the given parameter
  struct ThFun_Params *get_args = (struct ThFun_Params *)args;

  int start, end;

  // Calculate the limits where to apply the operations
  // Each portion is given to a thread
  start = get_args->id * (double)get_args->object_count / get_args->no_threads;
  end = min((get_args->id + 1) * (double)get_args->object_count /
				get_args->no_threads,
			get_args->object_count);

  // Set initial generation (composed of object_count individuals with a single
  // item in the sack)
  for (int i = start; i < end; ++i) {
	get_args->current_generation[i].fitness = 0;
	get_args->current_generation[i].chromosomes =
		(int *)calloc(get_args->object_count, sizeof(int));
	get_args->current_generation[i].chromosomes[i] = 1;
	get_args->current_generation[i].index = i;
	get_args->current_generation[i].chromosome_length = get_args->object_count;

	get_args->next_generation[i].fitness = 0;
	get_args->next_generation[i].chromosomes =
		(int *)calloc(get_args->object_count, sizeof(int));
	get_args->next_generation[i].index = i;
	get_args->next_generation[i].chromosome_length = get_args->object_count;
  }

  // Declare 2 variables that keep the generations arrays
  individual *current_generation = get_args->current_generation;
  individual *next_generation = get_args->next_generation;

  iterate_generations(get_args);

  // Wait for all threads
  pthread_barrier_wait(get_args->barrier);

  // Compute fitness between the limits
  compute_fitness_function(get_args->objects, current_generation,
						   get_args->object_count, get_args->sack_capacity,
						   start, end);

  pthread_barrier_wait(get_args->barrier);

  // Sort the section
  qsort(current_generation + start, end - start, sizeof(individual), cmpfunc);

  // Wait for all threads to finish
  pthread_barrier_wait(get_args->barrier);

  // Merge the sections on a single thread
  if (get_args->id == 0) {
	int l = 0 * (double)get_args->object_count / get_args->no_threads;
	for (int i = 0; i < get_args->no_threads; i++) {

	  int r =
		  min((i + 2) * (double)get_args->object_count / get_args->no_threads,
			  get_args->object_count - 1);
	  int m = l + (r - l) / 2;

	  merge(current_generation, l, m, r);
	}
  }

  pthread_barrier_wait(get_args->barrier);

  // Print the best fitness value
  if (get_args->id == 0)
	print_best_fitness(current_generation);
  return NULL;

  if (get_args->id == 0) {
	// free resources for old generation
	free_generation(current_generation);
	free_generation(next_generation);

	// free resources
	free(current_generation);
	free(next_generation);
  }

  // Exit thread
  pthread_exit(NULL);
}